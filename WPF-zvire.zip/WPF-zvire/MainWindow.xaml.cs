﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WPF_zvire.Classes;

namespace WPF_zvire
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            PopulateAnimalList();
        }

        private void PopulateAnimalList()
        {
           
            List<Zvire> zvirata = new List<Zvire>
            {
                new Ptak { CoJeTo = "Pták", PocetNohou = 2,Jmeno = "Karel" ,UmiLetat = true, Barva = "Modrá", RozpetiKridel = 10.5 },
                new Pes { CoJeTo = "Pes", PocetNohou = 4,Jmeno = "Alík" ,UmiLetat = false, Barva = "Hnědá", VelikostHlavy = "Velká" },
                new Ryba { CoJeTo = "Ryba", PocetNohou = 0,Jmeno = "David" ,UmiLetat = false, Barva = "Stříbrná", DruhVody = "Sladká" }
            };

            animalListBox.ItemsSource = zvirata;
        }

        private void AnimalListBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            Zvire selectedAnimal = (Zvire)animalListBox.SelectedItem;

            if (selectedAnimal != null)
            {
                string message = $"Co je to za zvíře: {selectedAnimal.CoJeTo}\n" +
                                 $"Počet nohou: {selectedAnimal.PocetNohou}\n" +
                                 $"Umí letat: {selectedAnimal.UmiLetat}\n" +
                                 $"Barva: {selectedAnimal.Barva}";

                if (selectedAnimal is Ptak)
                {
                    Ptak selectedBird = (Ptak)selectedAnimal;
                    message += $"\nRozpětí křídel: {selectedBird.RozpetiKridel}";
                }
                else if (selectedAnimal is Pes)
                {
                    Pes selectedDog = (Pes)selectedAnimal;
                    message += $"\nVelikost hlavy: {selectedDog.VelikostHlavy}";
                }
                else if (selectedAnimal is Ryba)
                {
                    Ryba selectedFish = (Ryba)selectedAnimal;
                    message += $"\nDruh vody: {selectedFish.DruhVody}";
                }

                MessageBox.Show(message, "Informace o zvířeti");
            }
        }
    }
}
