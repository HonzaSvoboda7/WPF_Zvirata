﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_zvire
{
    public class Zvire
    {
        private int _pocetNohou;
        private bool _umiLetat;
        private string _barva;
        private string _jmeno;
        public string _cojeto;
        public int PocetNohou
        {
            get { return _pocetNohou; }
            set
            {
                _pocetNohou = value;
                OnPropertyChanged("PocetNohou");
            }
        }

        public bool UmiLetat
        {
            get { return _umiLetat; }
            set
            {
                _umiLetat = value;
                OnPropertyChanged("UmiLetat");
            }
        }

        public string Barva
        {
            get { return _barva; }
            set
            {
                _barva = value;
                OnPropertyChanged("Barva");
            }
        }

        public string Jmeno
        {
            get { return _jmeno; }
            set
            {
                _jmeno = value;
                OnPropertyChanged("Barva");
            }
        }
        public string CoJeTo
        {
            get { return _cojeto; }
            set
            {
                _cojeto = value;
                OnPropertyChanged("Barva");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

   





}
