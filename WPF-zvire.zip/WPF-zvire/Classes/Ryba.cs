﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_zvire.Classes
{
    public class Ryba : Zvire
    {
        private string _druhVody;

        public string DruhVody
        {
            get { return _druhVody; }
            set
            {
                _druhVody = value;
                OnPropertyChanged("DruhVody");
            }
        }
    }
}

