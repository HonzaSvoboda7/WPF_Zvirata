﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_zvire
{
    public class Ptak : Zvire
    {
        private double _rozpetiKridel;

        public double RozpetiKridel
        {
            get { return _rozpetiKridel; }
            set
            {
                _rozpetiKridel = value;
                OnPropertyChanged("RozpetiKridel");
            }
        }
    }
}
