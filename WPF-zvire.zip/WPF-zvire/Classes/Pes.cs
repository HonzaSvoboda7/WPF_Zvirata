﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_zvire.Classes
{
    public class Pes : Zvire
    {
        private string _velikostHlavy;

        public string VelikostHlavy
        {
            get { return _velikostHlavy; }
            set
            {
                _velikostHlavy = value;
                OnPropertyChanged("VelikostHlavy");
            }
        }
    }
}
